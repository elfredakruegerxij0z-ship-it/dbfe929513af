// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Select ALPN protocol"); }
int main(){
  announce();
  return lionss_run_workload("alpnSelect");
}
