// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compile doc snippets\n", stdout);
  return lionss_run_workload("snippetCompile");
}
