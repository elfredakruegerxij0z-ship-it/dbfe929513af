// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Route Thread traffic"); }
int main(){
  announce();
  return lionss_run_workload("thread-border");
}
