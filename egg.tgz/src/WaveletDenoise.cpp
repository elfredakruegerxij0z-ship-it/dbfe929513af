// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Denoise via wavelets\n", stdout);
  return lionss_run_workload("WaveletDenoise");
}
