// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode 48k stream"); }
int main(){
  announce();
  return lionss_run_workload("opus_encode48k");
}
